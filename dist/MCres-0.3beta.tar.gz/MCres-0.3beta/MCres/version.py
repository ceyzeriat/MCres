# -*- coding: utf-8 -*-
# Written by Guillaume Schworer, 2015

__major__ = 0
__minor__ = 2
__version__ = "v"+str(__major__)+"."+str(__minor__)+"beta"

major = __major__
minor = __minor__
version = __version__
